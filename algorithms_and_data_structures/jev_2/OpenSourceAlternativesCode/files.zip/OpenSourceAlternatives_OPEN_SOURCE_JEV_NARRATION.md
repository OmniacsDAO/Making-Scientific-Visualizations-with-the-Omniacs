# Open-Source JEV Alternatives — Narration & Timing

**Target runtime:** ~5:55  
**Comfortable range:** 5:40–6:10  
**Tone:** curious, technical, visual, non-hype  
**Core thesis:** Open-source projects have converged on the *same typed-probability interface* through radically different architectures and training methods.

---

## 0:00–0:30 — One API, many machines

TypeSafe's Jev introduced a strange interface for AI: give the model messy state, define the decisions you care about, and get probabilities instead of prose.

Open source moved fast. But the projects that now look like Jev from the outside are often completely different machines inside. Some are tiny BERT-style encoders. Some are ordinary Qwen models whose logits are read instead of generated. Others add decision heads, contrastive embeddings, or even a diffusion language model.

So "Jev-like" is already becoming less of an architecture—and more of a category.

## 0:30–1:00 — What official Jev actually tells us

TypeSafe says Jev uses a new architecture, a parallel sampler, and Reinforcement Learning for Calibrated Decisions—or RLCD.

The public abstraction is clear: unstructured state in; typed probabilistic decisions out, with multiple outputs produced in parallel.

But the internals remain closed. We do not have the weights, architecture specification, training corpus, or exact RLCD recipe.

So an open model can reproduce Jev's *behavioral contract* without reproducing Jev itself.

## 1:00–1:52 — Family one: build a real decision model

At one end are models explicitly built for finite decisions.

Julia-1 starts from mmBERT-small, adds decision components, and turns a 144-million-parameter multilingual encoder into a model that scores supplied choices. It can even run on a CPU. Its training pipeline is not public, but this is clearly not a chat model with a wrapper.

Laya goes further. Its BERT-family encoders are trained with reinforcement learning against strictly proper scoring rules. The policy outputs probabilities, noise explores nearby distributions, and REINFORCE-style updates reward honest probability estimates—not merely correct argmax answers.

Von and Verdict take a different route: cross-entropy plus Brier-style calibration losses and temperature scaling.

That distinction matters. *Training for calibration* is not automatically *reinforcement learning*. Open projects use the label RLCD for several technically different procedures.

## 1:52–2:42 — Family two: what if the decision model was already inside the LLM?

Now the shortcut.

A causal language model already ends a forward pass with thousands of logits: scores for the next token.

Tell Qwen that A means billing, B means technical support, and C means sales. Instead of letting it generate a response, stop. Keep only the logits for A, B, and C, then softmax those three numbers.

That is essentially what SemIf explores with frozen Qwen. No new model weights are required.

Reflex takes the idea further. Its author reports that fine-tuning improved some familiar tasks but hurt broader judgment, so the recommended release keeps the backbone frozen and reads it directly, with option-order handling.

Cygnet uses a similar trick with stock Gemma.

Part of the "decision model" may already exist inside the LLM. Generation was simply one way of reading it.

## 2:42–3:32 — Family three: train the readout

Other projects keep that simple option-logit readout but fine-tune the foundation model.

Hopper adds a rank-16 LoRA to Qwen3.5-4B and still reads only option letters. Nimble trains cross-entropy directly over allowed candidate logits.

JevK5 mixes teacher-written decisions, replay examples, and soft target distributions when available. Plumb then fine-tunes JevK5 again, emphasizing hard or uncertain cases.

Decider is especially interesting. Most of its training is supervised, but one 2B lineage then received 384 calibration-aware reinforcement-learning updates on browser tasks and games where real outcome distributions were measurable. Here the reward really comes from outcomes.

So almost identical inference—letter logits, restricted softmax, temperature scaling—can hide radically different developmental histories.

## 3:32–4:15 — Family four: remove the language head

Another group keeps the language backbone but replaces the readout.

Kev adds a learned pointer head. It compares each option's hidden state with a special decision state, then softmaxes those compatibility scores. The normal vocabulary head is not choosing the answer.

Zefan Cai's Open-Jev uses LoRA plus a scalar decision head initialized from the model's existing Yes-versus-No representation, then trains it with soft cross-entropy, a Brier term, and temperature calibration.

NanoJev uses shared decision heads: set attention for variable choices, sigmoid for Boolean decisions, and distributions over ordered scores.

Same foundation-model knowledge. Different readout machinery.

## 4:15–4:42 — Family five: contrastive decisions

CLM changes the problem again.

It embeds the state and each candidate action separately. Contrastive InfoNCE training pulls the correct state-action pair together and pushes incorrect actions away.

At inference, it computes dot products between the state embedding and candidate action embeddings, then softmaxes the similarities.

A typed decision becomes geometry in a learned semantic space.

## 4:42–5:05 — And then DiffusionGemma breaks the pattern

OpenJev's DiffusionGemma backend is different again.

Qwen-style models are causal. DiffusionGemma can operate on a token canvas with masked answer positions. OpenJev places answer slots on that canvas and reads probabilities at those positions rather than decoding prose.

That feels much closer to simultaneous prediction—though there is no public evidence that TypeSafe Jev uses the same architecture.

## 5:05–5:35 — The calibration trap

All these systems expose probabilities. But softmax is not automatically trustworthy confidence.

If a model says ninety percent, calibration asks: across many predictions near ninety percent confidence, is it actually right about ninety percent of the time?

A raw logit readout might say ninety percent and be correct only sixty percent of the time. Temperature scaling can reshape confidence without changing the winning answer. Proper scoring rules train the distribution itself. Outcome-driven RL can reward beliefs against what really happens.

"Probabilities out" is only half the problem. The other half is whether those probabilities deserve to be trusted.

## 5:35–5:55 — Closing

That is what makes the open Jev ecosystem interesting.

Jev helped make the interface legible: state in, typed decisions and uncertainty out.

Open source is exploring everything underneath it—from 144-million-parameter encoders, to frozen logits, LoRA adapters, custom heads, contrastive embeddings, and diffusion models.

**Decision models are becoming their own category of AI—and there may be many ways to build one.**
